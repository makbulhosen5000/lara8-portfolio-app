<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\About;
use App\Models\Contact;
use App\Models\Logo;
use App\Models\News;
use App\Models\Product;
use App\Models\Slider;

class BlogController extends Controller
{

    //
}
